var searchData=
[
  ['pair_0',['pair',['../structpair.html',1,'']]],
  ['process_1',['process',['../structprocess.html',1,'']]]
];
