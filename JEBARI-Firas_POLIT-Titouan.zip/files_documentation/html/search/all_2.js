var searchData=
[
  ['calcul_5ffinger_0',['calcul_finger',['../_exercice1_8c.html#ae63971d7267352204193312eacd9de1f',1,'calcul_finger(struct pair *pairs):&#160;Exercice1.c'],['../_exercice2_8c.html#ae63971d7267352204193312eacd9de1f',1,'calcul_finger(struct pair *pairs):&#160;Exercice2.c'],['../_exercice3_8c.html#a914922a08a3e9cd10a6070315a1bffdf',1,'calcul_finger(struct pair *pairs, int size):&#160;Exercice3.c']]],
  ['calcul_5freverse_1',['calcul_reverse',['../_exercice3_8c.html#afab3dab26ccd036b62de2cd6c4f4ca1c',1,'Exercice3.c']]]
];
