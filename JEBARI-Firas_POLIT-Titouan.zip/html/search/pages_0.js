var searchData=
[
  ['distributed_20algorithmic_20project_0',['Distributed Algorithmic Project',['../md__r_e_a_d_m_e.html',1,'']]]
];
