var indexSectionsWithContent =
{
  0: "abcefilmprstw",
  1: "fp",
  2: "e",
  3: "abcefilmprstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions"
};

